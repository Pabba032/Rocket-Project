import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BigExplosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BigExplosion extends Actor
{
    private int delayTime;
    public void act() 
    {
        delayTime++;
        if(delayTime>8)
        {
            getWorld().removeObject(this);
        }
        
    }     
}

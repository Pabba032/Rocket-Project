import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Space extends World
{
    public static Rocket rocket;
    public Space()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1); 
        rocket = new Rocket(2);
        addObject(rocket,getWidth()/2,getHeight()/2);
        addObject(new Asteroids(),203,127);
        addObject(new Asteroids(3,3,1),510,70);
        addObject(new Asteroids(2,2,0),576,418);
    }
    public void act()
    {
        showText("Score: "+Space.rocket.score,100,50);
        showText("Lives: "+Space.rocket.lives,200,50);
        youWin();
        gameOver();
    }
    public void youWin()
    {
        if(Space.rocket.score == 5)
        {
            addObject(new YouWin(),getWidth()/2,getHeight()/2);
            Greenfoot.stop();
        }
        
    }
    
    public void gameOver()
    {
        if(Space.rocket.lives == 0)
        {
            addObject(new GameOver(),getWidth()/2,getHeight()/2);
            Greenfoot.stop();
        }
    }
}

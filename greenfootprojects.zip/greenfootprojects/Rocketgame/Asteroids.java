import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Asteroids here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Asteroids extends Actor
{
    private int wSize;
    private int hSize;
    private int choice;
    public Asteroids()
    {
        
    }
    public Asteroids(int wSize,int hSize,int choice)
    {
        this.wSize=wSize;
        this.hSize=hSize;
        if(choice==1)
        {
            changeIncSize();
        }
        else
        {
            changeDecSize();
        }
    }
    
    public void changeIncSize()
    {
        GreenfootImage img = getImage();
        img.scale(img.getWidth()*this.wSize,img.getHeight()*this.hSize);
    }
    public void changeDecSize()
    {
        GreenfootImage img = getImage();
        img.scale(img.getWidth()/this.wSize,img.getHeight()/this.hSize);
    }
    public void act() 
    {
        move(1);
        bounceBack();
        hitByMissile();
    }
    public void bounceBack()
    {
        if(isAtEdge())
        {
            int randomDegree = Greenfoot.getRandomNumber(10);
            turn(randomDegree);
        }
    }
    
    public void hitByMissile()
    {
        if(isTouching(Missile1.class))
        {
            removeTouching(Missile1.class);/*another class object get remove
            by using removeTouching()*/
            Space.rocket.score++;
            getWorld().addObject(new SmallExplosion(),getX(),getY());
            if(getImage().getWidth()<=58)
            {
                getWorld().removeObject(this);
            }
            else 
            {
                removeTouching(Missile1.class);
                Asteroids a1=new Asteroids();
                Asteroids a2=new Asteroids();
                getWorld().addObject(a1,getX(),getY());
                getWorld().addObject(a2,getX(),getY());
                int rn1=Greenfoot.getRandomNumber(90);//static method so calling
                int rn2=Greenfoot.getRandomNumber(30);//using classname Greenfoot
                a1.setRotation(rn1);
                a2.setRotation(rn2);
                getWorld().removeObject(this);
            }
        }
    }
}

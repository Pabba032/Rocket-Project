import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Missile2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Missile2 extends Actor
{
    private int gravity;
    public Missile2()
    {
        getImage().scale(getImage().getWidth()/3,getImage().getHeight()/3);
    }
    public void act() 
    {
        move(4);
        drop();
    }
    public void drop()
    {
        if(isAtEdge())
        {
            getWorld().removeObject(this);
        }
        else
        {
        gravity++;
        setLocation(getX(),getY()+gravity);
        }
    }
}


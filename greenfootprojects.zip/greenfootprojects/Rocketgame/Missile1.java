import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Missile1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Missile1 extends Actor
{
    private int cwidth;
    private int cheight;
    private GreenfootImage img;
    private World world;
    private int speed;  
    private int gravity;
    public Missile1()
    {
        configure();
    }
    public void configure()
    {
        img = getImage();
        cwidth = img.getWidth();
        cheight = img.getHeight();
        img.scale(cwidth/2,cheight/2);
        world=getWorld();
    }
   
    public void configureWorld()
    {
        world=getWorld();
    }
    public void act() 
    {
        move(4);
        disappear();
        configureWorld();
        if(gravity<=8)
        {
            drop();
        }
    }  
    public void disappear()
    {
        if(isAtEdge())
        {
            world.removeObject(this);//entire Object
        }
    }
    public void drop()
    {
     gravity++;
     setLocation(getX(),getY()+gravity);
    }
}

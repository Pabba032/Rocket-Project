import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SmallExplosion here.
 * 
 * @author (Nithisha) 
 * @version (a version number 31/12/20)
 */
public class SmallExplosion extends Actor
{
    private int delayTime;
    public SmallExplosion()
    {
        getImage().scale(getImage().getWidth()*3,getImage().getHeight()*3);
    }
    public void act() 
    {
        delayTime++;
        if(delayTime>10)
        {
            getWorld().removeObject(this);
        }
        
    }    
}
